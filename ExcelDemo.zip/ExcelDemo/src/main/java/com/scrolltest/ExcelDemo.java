package com.scrolltest;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ExcelDemo {
    public static void main(String[] args) {
        WebDriver driver = new FirefoxDriver( );
        readFile( );
//        String[] recordToAdd = {"Aman","LeadSDET"};
//        writeExcel(recordToAdd);
        driver.quit();


    }

//    private static void writeExcel(String[] recordToAdd) {
//        File file = new File("src/main/java/com/scrolltest/TestDATA.xlsx");
//        FileInputStream inputStream = null;
//        try {
//            inputStream = new FileInputStream(file);
//            Workbook testDataWorkBook1 = new XSSFWorkbook(inputStream);
//            Sheet testDataSheet1 = testDataWorkBook1.getSheet("Sheet1");
//            int rowCount1 = testDataSheet1.getLastRowNum()-testDataSheet1.getFirstRowNum();
//            Row row = testDataSheet1.getRow(0);
//            Row newRow = testDataSheet1.createRow(rowCount1+1);
//            for(int j = 0; j < row.getLastCellNum(); j++){
//                //Fill data in row
//                Cell cell = newRow.createCell(j);
//                cell.setCellValue(recordToAdd[j]);
//            }
//            inputStream.close();
//
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace( );
//        } catch (IOException e) {
//            e.printStackTrace( );
//        }
//
//    }

    private static void readFile() {
        try {
            File file = new File("src/main/java/com/scrolltest/TestDATA.xlsx");
            FileInputStream inputStream = new FileInputStream(file);
            Workbook testDataWorkBook = new XSSFWorkbook(inputStream);
            Sheet testDataSheet = testDataWorkBook.getSheet("Sheet1");
            int rowCount = testDataSheet.getLastRowNum( ) - testDataSheet.getFirstRowNum( );
            for (int i = 0; i < rowCount + 1; i++) {

                Row row = testDataSheet.getRow(i);
                //Create a loop to print cell values in a row
                for (int j = 0; j < row.getLastCellNum( ); j++) {
                    //Print Excel data in console
                    System.out.print(row.getCell(j).getStringCellValue( ) + "|| ");
                }
                System.out.println( );
            }
            inputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace( );
        } catch (IOException e) {
            e.printStackTrace( );
        }


    }
}
