package com.scrolltest;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class DDT {

    private WebDriver driver;
    private XSSFWorkbook workbook;
    private XSSFSheet sheet;
    private XSSFCell cell;

    public DDT() {

    }


    @Test(priority = 0)
    public void testFullPage() throws IOException {

        File file = new File("src/main/java/com/scrolltest/TD.xlsx");
        FileInputStream fis = new FileInputStream(file);
        workbook = new XSSFWorkbook(fis);
        sheet = workbook.getSheetAt(0);
        for (int i = 1; i <= sheet.getLastRowNum( ); i++) {

            cell = sheet.getRow(i).getCell(0);
            DataFormatter formatter = new DataFormatter();
            String username = formatter.formatCellValue(cell);
            cell = sheet.getRow(i).getCell(1);
            String password = formatter.formatCellValue(cell);
            driver.findElement(By.name("userName")).sendKeys(username );
            driver.findElement(By.name("password")).sendKeys(password );
            driver.findElement(By.name("submit")).click( );
            driver.manage( ).timeouts( ).implicitlyWait(3, TimeUnit.SECONDS);
            Assert.assertTrue(driver.findElement(By.linkText("SIGN-OFF")).isDisplayed( ));
            driver.findElement(By.linkText("SIGN-OFF")).click();

        }

    }

    @BeforeTest
    public void beforeTest() {
        driver = new FirefoxDriver( );
        driver.get("http://demo.guru99.com/test/newtours/index.php");
        driver.manage( ).window( ).maximize( );
        driver.manage( ).timeouts( ).implicitlyWait(5, TimeUnit.SECONDS);

    }

    @AfterTest
    public void afterTest() {
        driver.quit( );
    }

}
